execute at @s run summon item ~ ~ ~ {Item:{id:"minecraft:music_disc_11", Count:1b, components:{custom_model_data:1, jukebox_playable:{song:"utopia:hakitaclosingtime"}}}}
